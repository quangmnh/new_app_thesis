import random as rd
a = []
for i in range(8):
    a.append(round(((24550-24370)*rd.random()+24370),11))
print(a)